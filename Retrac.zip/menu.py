from colorama import Fore, Style, init
import os
from pathlib import Path
import json

init(autoreset=True)
HERE = Path(__file__).parent  
RETRAC = HERE / "Profiles/retrac.json"
COMMON_CORE = HERE / "Profiles/common_core.json"

class Menu:
    def __init__(self):
        self.author = "Star"
        self.discord = "https://discord.gg/7a8ZeDJv2p"

        self.menu_options = [
            "Edit Level",
            "Edit V-Bucks",
            "Start",
            "Exit"
        ]

        self.level: int = 1
        self.vbucks: int = 0

    def clear(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def title(self):
        self.clear()
        print(Fore.GREEN + Style.BRIGHT + """░██████████                                  ░██                                   
░██                                          ░██                                   
░██        ░██░████  ░███████   ░███████  ░████████ ░██░████  ░██████    ░███████  
░█████████ ░███     ░██    ░██ ░██    ░██    ░██    ░███           ░██  ░██    ░██ 
░██        ░██      ░█████████ ░█████████    ░██    ░██       ░███████  ░██        
░██        ░██      ░██        ░██           ░██    ░██      ░██   ░██  ░██    ░██ 
░██        ░██       ░███████   ░███████      ░████ ░██       ░█████░██  ░███████  
                                                                                   
                                                                                   
                                                                                   """)
        
        print(Fore.CYAN + Style.BRIGHT + f"               Author: {self.author} | Discord: {self.discord}\n")

    def options(self):
        for i, option in enumerate(self.menu_options, start=1):
            print(Fore.YELLOW + Style.BRIGHT + f"               [{i}] {option}")
        print()
    
    def get_choice(self) -> int:
        while True:
            try:
                choice = int(input(Fore.GREEN + Style.BRIGHT + "               Select an option: "))
                if 1 <= choice <= len(self.menu_options):
                    return choice
                else:
                    print(Fore.RED + Style.BRIGHT + "               Invalid option. Please try again.")
            except ValueError:
                print(Fore.RED + Style.BRIGHT + "               Invalid input. Please enter a number.")

    def load_stats(self):
        try:
            if COMMON_CORE.exists() and RETRAC.exists():
                with open(COMMON_CORE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                if "profileChanges" in data and len(data["profileChanges"]) > 0:
                    for change in data["profileChanges"]:
                        if change["changeType"] == "fullProfileUpdate":
                            profile = change["profile"]
                            items = profile["items"]
                            
                            vbucks_item_id = "gyattinohio"
                            if vbucks_item_id in items:
                                self.vbucks = items[vbucks_item_id]["quantity"]
                            
                with open(RETRAC, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if "profileChanges" in data and len(data["profileChanges"]) > 0:
                    for change in data["profileChanges"]:
                        if change.get("changeType") == "fullProfileUpdate":
                            profile = change.get("profile", {})
                            stats = profile.get("stats", {})
                            attributes = stats.get("attributes", {})
                            
                            level_fields = ["book_level", "book_xp", "level", "accountLevel"]
                            self.level = attributes.get("level", self.level)
        except:
            pass

    def display_stats(self):
        self.load_stats()
        print(Fore.CYAN + Style.BRIGHT + "               Current Stats:")
        print(Fore.CYAN + Style.BRIGHT + f"               Level: {self.level}")
        print(Fore.CYAN + Style.BRIGHT + f"               V-Bucks: {self.vbucks}")
        print()

    def upload_choice(self, choice: str, number: int) -> bool:
        try:
            if not COMMON_CORE.exists():
                print(Fore.RED + Style.BRIGHT + "               Profile file not found!")
                return False
            
            if choice.lower() == "level":
                with open(RETRAC, "r", encoding="utf-8") as f:
                    data = json.load(f)
                level_fields = ["book_level", "book_xp", "level", "accountLevel"]
                
                if "profileChanges" in data and len(data["profileChanges"]) > 0:
                    for change in data["profileChanges"]:
                        if change.get("changeType") == "fullProfileUpdate":
                            profile = change.get("profile", {})
                            stats = profile.get("stats", {})
                            attributes = stats.get("attributes", {})
                            
                            for field in level_fields:
                                if field in attributes:
                                    attributes[field] = number
                    
                    for stat_change in data["profileChanges"]:
                        if stat_change.get("changeType") == "statModified":
                            stat_name = stat_change.get("name")
                            if stat_name in ["book_level", "book_xp", "level", "accountLevel"]:
                                stat_change["value"] = number
                
                with open(RETRAC, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)
                
                self.level = number
                return True
                
            elif choice.lower() == "vbucks":
                with open(COMMON_CORE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if "profileChanges" in data and len(data["profileChanges"]) > 0:
                    for change in data["profileChanges"]:
                        if change["changeType"] == "fullProfileUpdate":
                            profile = change["profile"]
                            items = profile["items"]
                            
                            vbucks_item_id = "gyattinohio"
                            
                            if vbucks_item_id in items:
                                items[vbucks_item_id]["quantity"] = number
                            else:
                                print(Fore.RED + Style.BRIGHT + f"               V-Bucks item '{vbucks_item_id}' not found in items")
                                return False
                
                with open(COMMON_CORE, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)
                
                self.vbucks = number
                return True
            
        except Exception as e:
            print(Fore.RED + Style.BRIGHT + f"               Error updating profile: {e}")
            return False

    def get_level(self) -> int:
        while True:
            try:
                level = int(input(Fore.GREEN + Style.BRIGHT + "               Enter level: "))
                if level >= 1:
                    return level
                else:
                    print(Fore.RED + Style.BRIGHT + "               Level must be at least 1. Please try again.")
            except ValueError:
                print(Fore.RED + Style.BRIGHT + "               Invalid input. Please enter a valid number.")

    def get_vbucks(self) -> int:
        while True:
            try:
                vbucks = int(input(Fore.GREEN + Style.BRIGHT + "               Enter V-Bucks amount: "))
                if vbucks >= 0:
                    return vbucks
                else:
                    print(Fore.RED + Style.BRIGHT + "               V-Bucks cannot be negative. Please try again.")
            except ValueError:
                print(Fore.RED + Style.BRIGHT + "               Invalid input. Please enter a valid number.")

    def exit_message(self):
        print(Fore.CYAN + Style.BRIGHT + "\n               Thank you for using Freetrac! Goodbye!\n")

    def run(self):
        self.load_stats()
        while True:
            self.title()
            self.display_stats()
            self.options()
            choice = self.get_choice()

            if choice == 1:
                self.level = self.get_level()
                if self.upload_choice("level", self.level):
                    print(Fore.GREEN + Style.BRIGHT + f"\n               Level set to {self.level}!\n")
                input(Fore.YELLOW + Style.BRIGHT + "               Press Enter to continue...")
            elif choice == 2:
                self.vbucks = self.get_vbucks()
                if self.upload_choice("vbucks", self.vbucks):
                    print(Fore.GREEN + Style.BRIGHT + f"\n               V-Bucks set to {self.vbucks}!\n")
                input(Fore.YELLOW + Style.BRIGHT + "               Press Enter to continue...")
            elif choice == 3:
                print(Fore.GREEN + Style.BRIGHT + "\n               Starting...\n")
                break
            elif choice == 4:
                self.exit_message()
                exit()