import os
import json
from mitmproxy import http

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMMON_CORE = os.path.join(BASE_DIR, "Profiles", "common_core.json")

class CommonCore:
    def request(self, flow: http.HTTPFlow) -> None:
        pass

    def response(self, flow: http.HTTPFlow) -> None:
        url = flow.request.url.lower()
        method = flow.request.method

        if ("common_core" in url or "profileid=common_core" in url) and method == "GET":
            print(f"CommonCore request: {flow.request.method} {flow.request.url}")
            try:
                data = json.loads(flow.response.text)

                if "profileChanges" in data and len(data["profileChanges"]) > 0:
                    profile = data["profileChanges"][0].get("profile", {})
                    items = profile.get("items", {})
                    
                    # Find the V-Bucks item by templateId instead of specific item ID
                    v_bucks_item_id = None
                    for item_id, item_data in items.items():
                        if item_data.get("templateId") == "Currency:MtxPurchased":
                            v_bucks_item_id = item_id
                            break
                    
                    if v_bucks_item_id:
                        # Update the V-Bucks quantity
                        items[v_bucks_item_id]["quantity"] = 691123027
                        print(f"Updated V-Bucks quantity to 691,123,027 (item ID: {v_bucks_item_id})")
                    else:
                        print("V-Bucks item (Currency:MtxPurchased) not found in profile")
                    
                    flow.response = http.Response.make(
                        200,
                        json.dumps(data).encode('utf-8'),
                        {"Content-Type": "application/json"}
                    )
                else:
                    print("No profileChanges found in response")
                    
            except Exception as e:
                print(f"Error processing CommonCore response: {e}")